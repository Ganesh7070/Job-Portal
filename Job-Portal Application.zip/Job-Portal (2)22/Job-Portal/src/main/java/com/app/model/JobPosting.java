package com.app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class JobPosting {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String title;
	private String description;
	private String requirements;

	@ManyToOne
	@JoinColumn(name = "company_id")
	private Company company;

	private boolean isActive;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRequirements() {
		return requirements;
	}

	public void setRequirements(String requirements) {
		this.requirements = requirements;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "JobPosting [id=" + id + ", title=" + title + ", description=" + description + ", requirements="
				+ requirements + ", company=" + company + ", isActive=" + isActive + "]";
	}

	public JobPosting(Long id, String title, String description, String requirements, Company company,
			boolean isActive) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.requirements = requirements;
		this.company = company;
		this.isActive = isActive;
	}

	public JobPosting() {
		super();
		// TODO Auto-generated constructor stub
	}

}
