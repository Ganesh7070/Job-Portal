package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.model.User;
import com.app.model.Application;
import com.app.model.JobPosting;
import com.app.repository.ApplicationRepository;
import com.app.repository.JobPostingRepository;
import com.app.repository.UserRepository;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

	@Autowired
	private ApplicationRepository applicationRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private JobPostingRepository jobPostingRepository;

	@PostMapping
	public ResponseEntity<ApplicationRepository> applyForJob(@RequestBody Application application) {
		// Validate input
		validateApplication(application);

		// Check if user exists
		User user = userRepository.findById(application.getUser().getId())
				.orElseThrow(() -> new IllegalArgumentException("User not found."));

		// Check if job posting exists
		JobPosting jobPosting = jobPostingRepository.findById(application.getJobPosting().getId())
				.orElseThrow(() -> new IllegalArgumentException("Job Posting not found."));

		// Check if user has already applied for this job
		boolean hasApplied = applicationRepository.existsByUserAndJobPosting(user, jobPosting);
		if (hasApplied) {
			throw new IllegalArgumentException("User has already applied for this job.");
		}

		application.setUser(user);
		application.setJobPosting(jobPosting);
		application.setStatus("Pending");

//        Application savedApplication = applicationRepository.save(application);
		return new ResponseEntity<ApplicationRepository>(HttpStatus.CREATED);
	}

	private void validateApplication(Application application) {
		// TODO Auto-generated method stub

	}

	@PutMapping("/{id}")
	public ResponseEntity<Application> updateApplicationStatus(@PathVariable Long id, @RequestParam String status) {
		Application application = applicationRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Application not found with id: " + id));

		// Validate and set status
		if (!status.equals("Pending") && !status.equals("Accepted") && !status.equals("Rejected")) {
			throw new IllegalArgumentException(
					"Invalid status. Status should be 'Pending', 'Accepted', or 'Rejected'.");
		}
		application.setStatus(status);

		Application updatedApplication = applicationRepository.save(application);
		return new ResponseEntity<>(updatedApplication, HttpStatus.OK);
	}

}
