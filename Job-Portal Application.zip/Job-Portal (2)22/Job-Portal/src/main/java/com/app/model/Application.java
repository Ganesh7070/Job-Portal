package com.app.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Application {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	@ManyToOne
	@JoinColumn(name = "job_id")
	private JobPosting jobPosting;

	private String resumeUrl;
	private String status; // e.g., "Pending", "Accepted", "Rejected"

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public JobPosting getJobPosting() {
		return jobPosting;
	}

	public void setJobPosting(JobPosting jobPosting) {
		this.jobPosting = jobPosting;
	}

	public String getResumeUrl() {
		return resumeUrl;
	}

	public void setResumeUrl(String resumeUrl) {
		this.resumeUrl = resumeUrl;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Application [id=" + id + ", user=" + user + ", jobPosting=" + jobPosting + ", resumeUrl=" + resumeUrl
				+ ", status=" + status + "]";
	}

	public Application(Long id, User user, JobPosting jobPosting, String resumeUrl, String status) {
		super();
		this.id = id;
		this.user = user;
		this.jobPosting = jobPosting;
		this.resumeUrl = resumeUrl;
		this.status = status;
	}

	public Application() {
		super();
		// TODO Auto-generated constructor stub
	}

}
