package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.model.JobPosting;
import com.app.repository.CompanyRepository;
import com.app.repository.JobPostingRepository;

import java.util.List;

@RestController
@RequestMapping("/api/jobpostings")
public class JobPostingController {

	@Autowired
	private JobPostingRepository jobPostingRepository;

	@PostMapping
	public ResponseEntity<JobPosting> createJobPosting(@RequestBody JobPosting jobPosting) {
		JobPosting savedJobPosting = jobPostingRepository.save(jobPosting);
		return new ResponseEntity<>(savedJobPosting, HttpStatus.CREATED);
	}

	@PutMapping("/{id}")
	public ResponseEntity<JobPosting> updateJobPosting(@PathVariable Long id,
			@RequestBody JobPosting jobPostingDetails) {
		JobPosting existingJobPosting = jobPostingRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Job Posting not found with id: " + id));

		existingJobPosting.setTitle(jobPostingDetails.getTitle());
		existingJobPosting.setDescription(jobPostingDetails.getDescription());
		existingJobPosting.setRequirements(jobPostingDetails.getRequirements());
		existingJobPosting.setActive(jobPostingDetails.isActive());

		JobPosting updatedJobPosting = jobPostingRepository.save(existingJobPosting);
		return new ResponseEntity<>(updatedJobPosting, HttpStatus.OK);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteJobPosting(@PathVariable Long id) {
		JobPosting existingJobPosting = jobPostingRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Job Posting not found with id: " + id));

		jobPostingRepository.delete(existingJobPosting);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	@GetMapping
	public List<JobPosting> getAllJobPostings() {
		return jobPostingRepository.findAll();
	}

	@GetMapping("/{id}")
	public ResponseEntity<JobPosting> getJobPostingById(@PathVariable Long id) {
		JobPosting jobPosting = jobPostingRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Job Posting not found with id: " + id));
		return new ResponseEntity<>(jobPosting, HttpStatus.OK);
	}

	@GetMapping("/search")
	public List<JobPosting> searchJobPostingsByTitle(@RequestParam String keyword) {
		return jobPostingRepository.findByTitleContainingIgnoreCase(keyword);
	}
}