package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.app.model.Company;
import com.app.repository.CompanyRepository;

import java.util.List;

@RestController
@RequestMapping("/api/companies")
public class CompanyController {

	@Autowired
	private CompanyRepository companyRepository;

	// Endpoint to create a new company
	@PostMapping
	public ResponseEntity<Company> createCompany(@RequestBody Company company) {
		Company savedCompany = companyRepository.save(company);
		return new ResponseEntity<>(savedCompany, HttpStatus.CREATED);
	}

	// Endpoint to update an existing company
	@PutMapping("/{id}")
	public ResponseEntity<Company> updateCompany(@PathVariable Long id, @RequestBody Company companyDetails) {
		Company existingCompany = companyRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Company not found with id: " + id));

		existingCompany.setName(companyDetails.getName());
		existingCompany.setAddress(companyDetails.getAddress());
		// Add more fields to update as needed

		Company updatedCompany = companyRepository.save(existingCompany);
		return new ResponseEntity<>(updatedCompany, HttpStatus.OK);
	}

	// Endpoint to delete a company
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteCompany(@PathVariable Long id) {
		Company existingCompany = companyRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Company not found with id: " + id));

		companyRepository.delete(existingCompany);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	// Endpoint to get all companies
	@GetMapping
	public List<Company> getAllCompanies() {
		return companyRepository.findAll();
	}

	// Endpoint to get a company by id
	@GetMapping("/{id}")
	public ResponseEntity<Company> getCompanyById(@PathVariable Long id) {
		Company company = companyRepository.findById(id)
				.orElseThrow(() -> new IllegalArgumentException("Company not found with id: " + id));
		return new ResponseEntity<>(company, HttpStatus.OK);
	}
}
